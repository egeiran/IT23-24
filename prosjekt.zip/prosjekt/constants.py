WIDTH,HEIGHT = 42 * 20, 24 * 20
EXTRA_HEIGHT = 100
FPS = 60
acc_y = 0.6

GREY = (120, 120, 128)

# PLAYER CONSTANTS
ANIMATION_DELAY = 60

"""
--------------------
--------------------
--------------------
--------XXXX--------
--------------------
--XXXX--------XXXX--
--------XXXX--------
XX----------------XX
--XXXXXXXXXXXXXXXX--
--------------------
"""