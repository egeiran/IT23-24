kroppen = ["abcde", "fghij", "klmno"]

kroppen[1] = kroppen[1].replace(kroppen[1][2], "a")