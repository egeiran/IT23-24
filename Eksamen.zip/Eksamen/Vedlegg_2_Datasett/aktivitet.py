import json
import time
import os
import sys

class Aktivitet:
    def __init__(self, navn: str, alle: int, menn: int, kvinner: int) -> None:
        self.navn = navn
        self.alle = alle
        self.menn = menn
        self.ordbok = {
            "Alle": alle,
            "Menn": menn,
            "Kvinner": kvinner
        }
        self.kvinner = kvinner
    
    def __str__(self) -> str:
        # Endrer hvordan en klasse printes
        return f"{self.navn}: \n  (Alle: {self.alle}, Menn: {self.menn}, Kvinner: {self.kvinner})"

    def __repr__(self) -> str:
        # Endrer hvordan en klasse vises i en liste
        return self.__str__()

class Hovedaktivitet(Aktivitet):
    def __init__(self, navn: str, alle: int, menn: int, kvinner: int) -> None:
        super().__init__(navn, alle, menn, kvinner)
        self.underaktiviteter: list[Underaktivitet] = []

    def __str__(self) -> str:
        return "\nH: " + super().__str__() + "{}".format(' '.join(underaktivitet.__str__() for underaktivitet in self.underaktiviteter))

class Underaktivitet(Aktivitet):
    def __init__(self, navn: str, alle: int, menn: int, kvinner: int) -> None:
        super().__init__(navn, alle, menn, kvinner)
    
    def __str__(self) -> str:
        return "\n  U: " + super().__str__()

def Sorter_Aktiviteter(liste, kjønn):
    """
        Sorterer en liste med aktiviteter basert på kjønn og tiden de bruker på det
    """
    ny_liste = sorted(liste, key= lambda aktivitet:aktivitet.ordbok[kjønn], reverse=True)
    return ny_liste
    
def vent():
    for i in range(4):
        print("."*(i))
        time.sleep(0.2)
        rens_terminal()

def rens_terminal():
    if sys.platform == "Windows":
        os.system("cls")
    else:
        os.system("clear")

with open("datasett.json", "r", encoding="utf-8") as f:
    data = json.load(f)

hovedaktiviteter = []

for i in range(0, len(data), 3):
    navn = data[i]["alle aktiviteter"]
    alle = data[i]["Tidsbruk 2000 I alt"]
    menn = data[i + 1]["Tidsbruk 2000 I alt"]
    kvinner = data[i + 2]["Tidsbruk 2000 I alt"]
    if "� " not in data[i]["alle aktiviteter"]:
        hovedaktiviteter.append(Hovedaktivitet(navn, alle, menn, kvinner))
    else:
        navn = navn.replace("� ", "")
        hovedaktiviteter[-1].underaktiviteter.append(Underaktivitet(navn, alle, menn, kvinner))

while True:
    rens_terminal()
    print(f"-- Hvilken hovedaktivitet vil du ha? (1 til {len(hovedaktiviteter)}) --")
    print()
    for i in range(len(hovedaktiviteter)):
        print(f"{i + 1}: {hovedaktiviteter[i].navn} ({len(hovedaktiviteter[i].underaktiviteter)} underaktiviteter)")
    print("a: Avslutt")
    print()
    valg = input("> ")
    if valg not in "1234567a" or valg == "": 
        print()
        input("Valget må være a eller mellom 1 og 7.")          # Gjør at programmet venter til brukeren trykker enter
        vent()
    elif valg == "a":
        print()
        input("Avslutter")
        time.sleep(1)
        vent()
    else:
        input(hovedaktiviteter[int(valg) - 1])               # Gjør at programmet venter til brukeren trykker enter
        vent()