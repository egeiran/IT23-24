# Ting til Eksamen

## Databehandling

[Open my_script.py in VS Code](vscode://file/../)