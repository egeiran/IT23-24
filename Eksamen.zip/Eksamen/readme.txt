Python-versjon: 3.9.6
Biblioteker:
- pygame=2.5.2